#!/usr/bin/env python3
"""hashgen: generador y verificador de hashes (texto, archivos y stdin)."""

import argparse
import hashlib
import hmac
import sys

ALGORITHMS = ["md5", "sha1", "sha224", "sha256", "sha384", "sha512",
              "sha3_256", "sha3_512", "blake2b", "blake2s"]
CHUNK_SIZE = 1024 * 1024  # 1 MB


def hash_bytes(data: bytes, algo: str = "sha256", key: bytes | None = None) -> str:
    """Devuelve el hash hexadecimal de unos bytes (HMAC si se da `key`)."""
    if key is not None:
        return hmac.new(key, data, algo).hexdigest()
    return hashlib.new(algo, data).hexdigest()


def hash_file(path: str, algo: str = "sha256", key: bytes | None = None) -> str:
    """Hash de un archivo leído por bloques (soporta archivos grandes)."""
    h = hmac.new(key, digestmod=algo) if key is not None else hashlib.new(algo)
    with open(path, "rb") as f:
        while chunk := f.read(CHUNK_SIZE):
            h.update(chunk)
    return h.hexdigest()


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="hashgen", description="Genera y verifica hashes de texto o archivos.")
    src = p.add_mutually_exclusive_group()
    src.add_argument("-t", "--text", help="texto a hashear")
    src.add_argument("-f", "--file", help="ruta del archivo a hashear")
    p.add_argument("-a", "--algo", default="sha256", choices=ALGORITHMS,
                   help="algoritmo (por defecto: sha256)")
    p.add_argument("--all", action="store_true", help="mostrar todos los algoritmos")
    p.add_argument("--hmac", metavar="CLAVE", help="calcular HMAC con esta clave")
    p.add_argument("-v", "--verify", metavar="HASH",
                   help="comparar con un hash esperado")
    return p


def main(argv=None) -> int:
    args = build_parser().parse_args(argv)
    key = args.hmac.encode() if args.hmac else None
    algos = ALGORITHMS if args.all else [args.algo]

    try:
        if args.text is not None:
            compute = lambda a: hash_bytes(args.text.encode(), a, key)
        elif args.file:
            compute = lambda a: hash_file(args.file, a, key)
        else:  # stdin
            data = sys.stdin.buffer.read()
            compute = lambda a: hash_bytes(data, a, key)

        results = {a: compute(a) for a in algos}
    except (OSError, ValueError) as e:
        print(f"Error: {e}", file=sys.stderr)
        return 2

    if args.verify:
        expected = args.verify.strip().lower()
        ok = any(hmac.compare_digest(h, expected) for h in results.values())
        print("✔ Coincide" if ok else "✘ NO coincide")
        return 0 if ok else 1

    for algo, digest in results.items():
        print(f"{algo:<9} {digest}" if args.all else digest)
    return 0


if __name__ == "__main__":
    sys.exit(main())
