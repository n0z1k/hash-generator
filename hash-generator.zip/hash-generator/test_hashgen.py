import hashlib
import hashgen


def test_sha256_text():
    assert hashgen.hash_bytes(b"hola") == hashlib.sha256(b"hola").hexdigest()


def test_md5_known_value():
    assert hashgen.hash_bytes(b"", "md5") == "d41d8cd98f00b204e9800998ecf8427e"


def test_hmac_differs_from_plain():
    assert hashgen.hash_bytes(b"x", key=b"k") != hashgen.hash_bytes(b"x")


def test_file_matches_bytes(tmp_path):
    f = tmp_path / "a.txt"
    f.write_bytes(b"contenido")
    assert hashgen.hash_file(str(f)) == hashgen.hash_bytes(b"contenido")


def test_cli_verify_ok(capsys):
    digest = hashlib.sha256(b"hola").hexdigest()
    assert hashgen.main(["-t", "hola", "-v", digest]) == 0


def test_cli_verify_fail():
    assert hashgen.main(["-t", "hola", "-v", "00"]) == 1


def test_missing_file():
    assert hashgen.main(["-f", "no_existe.bin"]) == 2
