# hashgen

Generador y verificador de hashes en Python, sin dependencias externas.

## Características
- Hash de texto, archivos (por bloques, aptos para archivos grandes) o stdin
- Algoritmos: MD5, SHA-1, SHA-2, SHA-3, BLAKE2
- HMAC con clave
- Verificación de integridad contra un hash esperado

## Uso
```bash
python hashgen.py -t "hola mundo"                 # SHA-256 de un texto
python hashgen.py -f archivo.iso -a sha512        # hash de un archivo
python hashgen.py -t "hola" --all                 # todos los algoritmos
python hashgen.py -t "hola" --hmac miclave        # HMAC-SHA256
python hashgen.py -f archivo.iso -v <hash>        # verificar integridad
echo -n "hola" | python hashgen.py                # desde stdin
```

## Tests
```bash
pip install pytest
pytest
```

## Aviso
MD5 y SHA-1 están rotos criptográficamente: úsalos solo para checksums, no para
seguridad. **No uses esta herramienta para guardar contraseñas**; para eso usa
bcrypt, scrypt o Argon2.

## Licencia
MIT
